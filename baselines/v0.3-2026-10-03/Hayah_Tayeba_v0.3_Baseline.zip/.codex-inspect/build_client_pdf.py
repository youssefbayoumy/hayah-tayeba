from pathlib import Path
import sys, re, html, json

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '.codex-inspect/pdf-deps'))
import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.pdfgen import canvas
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    PageBreak, NextPageTemplate, KeepTogether, Table, TableStyle, Flowable, CondPageBreak)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
from pypdf import PdfReader

OUT = ROOT / 'output/pdf'
OUT.mkdir(parents=True, exist_ok=True)
PDF = OUT / 'Hayah_Tayeba_SRS_and_UML_Client_Review_v0.3.pdf'
for name, filename in [('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf'),('Arial-Italic','ariali.ttf'),('Arial-BoldItalic','arialbi.ttf')]:
    pdfmetrics.registerFont(TTFont(name, 'C:/Windows/Fonts/' + filename))
pdfmetrics.registerFontFamily('Arial', normal='Arial', bold='Arial-Bold', italic='Arial-Italic', boldItalic='Arial-BoldItalic')

INK = colors.HexColor('#183E42')
TEAL = colors.HexColor('#17676C')
TEXT = colors.HexColor('#263B43')
MUTED = colors.HexColor('#607078')
PALE = colors.HexColor('#EEF5F4')
LINE = colors.HexColor('#D5E0DF')

styles = {
 'body': ParagraphStyle('Body',fontName='Arial',fontSize=9.7,leading=14,textColor=TEXT,spaceAfter=7),
 'small': ParagraphStyle('Small',fontName='Arial',fontSize=8.4,leading=11.7,textColor=MUTED,spaceAfter=6),
 'h1': ParagraphStyle('Section',fontName='Arial-Bold',fontSize=23,leading=29,textColor=INK,spaceAfter=15,keepWithNext=True),
 'h2': ParagraphStyle('Heading2',fontName='Arial-Bold',fontSize=14,leading=18,textColor=TEAL,spaceBefore=14,spaceAfter=7,keepWithNext=True),
 'h3': ParagraphStyle('Heading3',fontName='Arial-Bold',fontSize=11,leading=15,textColor=INK,spaceBefore=9,spaceAfter=5,keepWithNext=True),
 'req': ParagraphStyle('Requirement',fontName='Arial-Bold',fontSize=10,leading=14,textColor=TEAL,spaceBefore=9,spaceAfter=4,keepWithNext=True),
 'cell': ParagraphStyle('Cell',fontName='Arial',fontSize=8.5,leading=11.8,textColor=TEXT,spaceAfter=0),
 'thead': ParagraphStyle('TableHead',fontName='Arial-Bold',fontSize=8.5,leading=11.7,textColor=colors.white),
 'bullet': ParagraphStyle('Bullet',fontName='Arial',fontSize=9.7,leading=14,textColor=TEXT,leftIndent=13,firstLineIndent=-10,spaceAfter=5),
}
styles['h2table']=ParagraphStyle('HeadingBeforeTable',parent=styles['h2'],keepWithNext=False)
styles['body'].allowWidows=0
styles['body'].allowOrphans=0

def arabic_runs(s):
    return re.sub(r'[\u0600-\u06ff]+(?:[ \u0600-\u06ff،؟]*[\u0600-\u06ff؟])?',
        lambda m:get_display(arabic_reshaper.reshape(m.group(0))), s)

def markup(text):
    text=text.replace('—',' - ').replace('–','-').replace('‑','-').replace('→',' to ')
    text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1',text)
    text=html.escape(arabic_runs(text))
    text=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',text)
    text=re.sub(r'`([^`]+)`',r'<font color="#17676C">\1</font>',text)
    return text

def p(s, style='body'): return Paragraph(markup(s),styles[style])

class VectorDiagram(Flowable):
    def __init__(self, path, maxw, maxh):
        super().__init__()
        self.drawing=svg2rlg(str(path))
        scale=min(maxw/self.drawing.width,maxh/self.drawing.height)
        self.width=self.drawing.width*scale
        self.height=self.drawing.height*scale
        self.scale=scale
        self.hAlign='CENTER'
    def draw(self):
        self.canv.saveState()
        self.canv.scale(self.scale,self.scale)
        renderPDF.draw(self.drawing,self.canv,0,0)
        self.canv.restoreState()

def header_footer(c,doc):
    w,h=c._pagesize
    c.saveState()
    if doc.page>1:
        c.setFillColor(TEAL)
        c.rect(42,h-34,w-84,2,fill=1,stroke=0)
        c.setFont('Arial-Bold',8)
        c.drawString(42,h-26,'HAYAH TAYEBA')
        c.setFont('Arial',8)
        c.setFillColor(MUTED)
        c.drawRightString(w-42,h-26,'SRS & UML | Client review draft v0.3')
    c.setStrokeColor(LINE)
    c.line(42,37,w-42,37)
    c.setFont('Arial',8)
    c.setFillColor(MUTED)
    c.drawString(42,23,'29 September 2026  |  Draft for review')
    c.drawRightString(w-42,23,str(doc.page))
    c.restoreState()

class SpecDoc(BaseDocTemplate):
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and hasattr(f,'bookmark'):
            self.canv.bookmarkPage(f.bookmark)
            self.canv.addOutlineEntry(f.getPlainText(),f.bookmark,level=0,closed=False)
            self.notify('TOCEntry',(0,f.getPlainText(),self.page,f.bookmark))

def section(title,key,break_before=True,template='body'):
    if break_before: story.extend([NextPageTemplate(template),PageBreak()])
    heading=p(title,'h1'); heading.bookmark=key
    story.append(heading)

def table(rows,width):
    n=len(rows[0])
    if n==2: weights=[.24,.76]
    elif n==3: weights=[.16,.42,.42]
    elif n==4: weights=[.11,.16,.15,.58]
    else: weights=[1/n]*n
    if rows[0][0] in ['ID','Requirement']: weights=([.12,.44,.44] if n==3 else weights)
    if n==4 and rows[0][1]=='Question': weights=[.12,.40,.21,.27]
    if n==4 and rows[0][0]=='Requirement': weights=[.17,.16,.12,.55]
    if n==3 and rows[0][0]=='Requirement': weights=[.20,.50,.30]
    data=[[p(cell,'thead' if i==0 else 'cell') for cell in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=[width*x for x in weights],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([
      ('BACKGROUND',(0,0),(-1,0),TEAL),('VALIGN',(0,0),(-1,-1),'TOP'),
      ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
      ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
      ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),
      ('LINEBELOW',(0,0),(-1,0),.5,TEAL),('LINEBELOW',(0,1),(-1,-1),.3,LINE)
    ]))
    return t

BODY_W=A4[0]-96

def emit_markdown(text):
    lines=text.splitlines(); i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line: i+=1; continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[:\- ]+',c or '-') for c in cells): rows.append(cells)
                i+=1
            if rows and rows[0][0]=='ID' and any(re.match(r'FR-\d+',r[0]) for r in rows[1:]):
                for r in rows[1:]:
                    block=[p(r[0]+'  |  '+r[1],'req')]
                    parts=r[2].split('**Accept:**')
                    block.append(p(parts[0]))
                    if len(parts)>1: block.append(p('**Acceptance:** '+parts[1]))
                    story.append(KeepTogether(block))
            elif rows and rows[0][0]=='ID' and any(re.match(r'NFR-\d+',r[0]) for r in rows[1:]):
                for r in rows[1:]:
                    story.append(p(r[0]+'  |  '+r[1],'req'))
                    story.append(p(r[2]))
            else:
                story.extend([table(rows,BODY_W),Spacer(1,7)])
            continue
        if line.startswith('# '): i+=1; continue
        if line.startswith('### '):
            story.extend([CondPageBreak(125),p(line[4:],'h3')]); i+=1; continue
        if line.startswith('## '):
            if line[3:]=='Open decisions': story.append(CondPageBreak(200))
            nxt=next((x.strip() for x in lines[i+1:] if x.strip()),'')
            if nxt.startswith('|'):
                story.append(CondPageBreak(100))
                story.append(p(line[3:],'h2table'))
            else: story.append(p(line[3:],'h2'))
            i+=1; continue
        if line.startswith('- '): story.append(p('- '+line[2:],'bullet')); i+=1; continue
        if re.match(r'^\d+\. ',line): story.append(p(line,'bullet')); i+=1; continue
        if line.startswith('```'):
            i+=1
            while i<len(lines) and not lines[i].startswith('```'): i+=1
            i+=1; continue
        paragraph=[line]; i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||- |\d+\. |```)',lines[i].strip()):
            paragraph.append(lines[i].strip()); i+=1
        story.append(p(' '.join(paragraph)))

def load(name):
    text=(ROOT/'docs'/name).read_text(encoding='utf-8')
    text=re.sub(r'^Version[^\n]*\n','',text,flags=re.M)
    return text

doc=SpecDoc(str(PDF),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=53,bottomMargin=50,
    title='Hayah Tayeba - Software Requirements and UML',author='Hayah Tayeba Project',
    subject='Client review draft v0.3 - requirements, use cases, architecture and UML')
templates=[]
for name,size in [('body',A4),('drawingP',A3),('drawingL',landscape(A3))]:
    w,h=size
    templates.append(PageTemplate(id=name,pagesize=size,frames=[Frame(48,50,w-96,h-108,
        leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=header_footer))
doc.addPageTemplates(templates)
story=[]

# Cover: no conversational history or local tooling details.
story.append(Spacer(1,80))
story.append(Paragraph('HAYAH TAYEBA',ParagraphStyle('CoverLabel',fontName='Arial-Bold',fontSize=12,leading=18,textColor=TEAL,spaceAfter=18)))
story.append(Paragraph(arabic_runs('الحياة الطيبة'),ParagraphStyle('ArabicTitle',fontName='Arial-Bold',fontSize=36,leading=49,textColor=INK,spaceAfter=24)))
story.append(Paragraph('Software Requirements<br/>&amp; UML Specification',ParagraphStyle('CoverTitle',fontName='Arial-Bold',fontSize=31,leading=39,textColor=INK,spaceAfter=22)))
story.append(p('Client review draft  |  Version 0.3  |  29 September 2026','small'))
story.append(Spacer(1,24))
story.append(p('A child-only learning app for ages 10-14, featuring one complete Dhikr door and an extensible admin content-management workflow.'))
story.append(Spacer(1,22))
story.append(table([['Review status','Purpose'],['Draft for review','Confirm scope and behavioral requirements before UI design and detailed implementation.'],['Confirmed and proposed items','Confirmed product direction is distinguished from proposed mechanisms and unresolved decisions.']],BODY_W))
story.append(Spacer(1,17))
story.append(p('Includes the SRS, ten active use cases and two retired identifiers, logical architecture, ten UML diagrams, and requirements-to-acceptance traceability.','small'))

section('Contents','contents')
toc=TableOfContents()
toc.levelStyles=[ParagraphStyle('TOC',fontName='Arial',fontSize=11,leading=18,textColor=INK,spaceBefore=8,leftIndent=0,rightIndent=20)]
story.append(toc)
story.append(Spacer(1,25))
story.append(p('How to read this document','h2'))
story.append(p('Start with the executive brief and decision register. Review the SRS and use cases before treating the models as an implementation baseline. The UML section uses larger pages where necessary to keep technical labels readable.'))
story.append(p('Status notation','h2'))
story.append(p('**D - derived:** operationalizes a confirmed product decision. **P - proposed:** mechanism or scope awaits agreement. **Must / Should:** priority within the proposed MVP. Normative wording makes a draft requirement testable; it does not mean it has already been approved.'))

section('01  Executive brief','brief')
emit_markdown('''
## Product direction
Hayah Tayeba helps children aged 10-14 understand a value, explore responses through a story, and try a small action in everyday life. The child is the only learner-facing role. Content administrators operate a separate authoring interface. The mobile client will use Expo React Native.

The first and only complete MVP door is **«باب الذكر»**, replacing the former good-character/anger journey. The full route introduces meaning, practical entry, continuing practice, and reflection. Children create their character before entering **«خريطة الحياة الطيبة»**. Arabic is the release language, with a locale-neutral structure for reviewed English editions later. Completion does not certify worship, emotional change, or spiritual growth.

## MVP boundary
- One complete Dhikr door with multiple learning stages for the child.
- Independent child progression after the proposed account setup.
- Saved learning progress and recovery from ordinary connection interruptions.
- An admin workflow for adding content using supported templates.
- Explicit content review, publication, revisions, and withdrawal.

## Decisions required before implementation
- Child setup, guest versus account access, and recovery of saved progress.
- Reflection modes, learner-data storage, and privacy.
- Child curriculum authorship, review, and asset-production ownership.
- Launch platforms, distribution countries, and connectivity expectations.
- Data-retention policy, operating ownership, and release quality targets.

## Delivery status
This document specifies a proposed solution. Application development, final curriculum production, religious-source verification, and product acceptance testing have not been completed. The supplied presentation, expanded project notes, and revised Dhikr concept are conceptual inputs rather than an approved finished curriculum.

## Review approach
Agree the behavioral scope first, then select backend technologies and physical data/API designs. UI prototyping can still reveal issues that require revisions to the specification. No price, delivery date, hosting provider, or launch commitment is established by this draft.
''')

section('02  Client revision and Dhikr scope','revision')
emit_markdown(load('CLIENT_REVISION.md'))

section('03  Decisions and open questions','decisions')
text=load('DECISIONS.md').split('## Revision history')[0]
text=text.replace('## Confirmed by the user','## Confirmed product direction')
text=text.replace('## What is deliberately not a requirement yet','## Items not yet adopted as requirements')
text=text.replace('The earlier Stitch prompt explored several of these details and is not an approved specification.','Exploratory visual concepts do not constitute approved product requirements.')
text=text.replace('user actually confirmed','project direction confirms').replace('User has not approved this boundary.','This visibility boundary requires confirmation.')
text=text.replace('## Proposed defaults — not yet approved','## Proposed defaults - awaiting confirmation')
text=text.replace('Priority means when an answer is needed, not an instruction to ask all questions at once.','The timing column identifies when each decision is needed for the next delivery stage.')
# Remove chat quotations from the confirmed-decision table; retain the substantive decisions.
clean=[]
for line in text.splitlines():
    if line.startswith('| ID | Confirmed decision |'): clean.append('| ID | Confirmed decision |'); continue
    if line.startswith('|---|---|---|') and clean and clean[-1]=='| ID | Confirmed decision |': clean.append('|---|---|'); continue
    if re.match(r'^\| C-\d+',line):
        cells=[c.strip() for c in line.strip().strip('|').split('|')]
        clean.append('| '+cells[0]+' | '+cells[1]+' |'); continue
    clean.append(line)
emit_markdown('\n'.join(clean))

section('04  Software requirements specification','srs')
text=load('SRS.md').replace('SRS approval, implementation verification, and educational validation are three different milestones. None is implied by creation of this draft.', '').replace('confirmed user decision','confirmed product decision')
text=text.replace('Sources C-xx and P-xx are defined in [DECISIONS.md](DECISIONS.md).','Sources C-xx and P-xx are defined in Section 03.')
text=text.replace('Use [TRACEABILITY.md](TRACEABILITY.md) for acceptance scenarios.','Use Section 08 for acceptance scenarios.')
emit_markdown(text)

section('05  Detailed use cases','usecases')
for chunk in re.split(r'(?=^## UC-)',load('USE_CASES.md'),flags=re.M):
    before=len(story)
    emit_markdown(chunk)
    if chunk.startswith('## UC-'):
        block=story[before:]
        del story[before:]
        story.append(KeepTogether(block))

section('06  Logical architecture','architecture')
text=load('ARCHITECTURE.md')
text=text.replace('the current task is requirements and UML before committing to a stack','the current stage establishes requirements and UML before committing to a stack')
emit_markdown(text)

diagrams=[
('01-use-cases','Use cases','The child and content admin are the only current actors. Retired adult learning and monitoring workflows are excluded. Content administration grants no access to learner records.','drawingP'),
('02-content-domain','Content domain','Conceptual classes, not physical database tables. Stable journeys have immutable revisions with child learning paths. Multiplicities describe a valid publishable model; drafts may be incomplete.','drawingP'),
('03-learner-domain','Learner domain','Each child is an independent learner with scoped identity and sessions. Attempts bind to content revisions. The access/recovery mechanism and simultaneous-device policy remain open.','drawingL'),
('04-child-activity','Child learning activity','Independent learning, durable local progress, optional practice/reflection steps, and network recovery. A locally finished session can still have synchronization pending.','drawingP'),
('05-child-access-sequence','Child access and recovery','Child profile setup, session resumption, and authorized recovery. Guest versus account access and recovery credentials are not selected. No companion account or approval is involved.','drawingL'),
('06-progress-sequence','Progress synchronization sequence','Separates local save from server confirmation and handles duplicate submissions. Only the authenticated child can restore their own progress; raw reflections remain outside progress payloads.','drawingL'),
('07-content-state','Content revision lifecycle','Publication freezes a revision. Editing creates another draft; withdrawal affects future availability without silently removing historical completion.','drawingP'),
('09-localization','Localization model','Arabic release and future English editions share canonical content IDs and progress. Localized text and media are versioned, reviewed editions.','drawingP'),
('10-practice-rewards','Practice and rewards','Remembering moments, plans, voluntary check-ins, and participation rewards. Reflection input/storage and seven-day gating remain open.','drawingP'),
('08-components','Logical components','Proposed client, backend, persistence, identity, and media boundaries. Backend modules do not imply separately deployed microservices or a selected vendor.','drawingL'),
]
diagrams.sort(key=lambda item: item[0])
section('07  UML models','uml')
story.append(p('The following ten models express the draft requirements. Behavioral mechanisms, privacy boundaries, and account ownership marked as proposals remain subject to review. These are software models, not UI layouts.'))
story.append(table([['Model','Purpose']]+[[title,desc] for _,title,desc,_ in diagrams],BODY_W))
story.append(p('Drawing pages use A3 dimensions so the original diagrams remain legible when zoomed or printed at their native size. Editable PlantUML sources are maintained with the project specification.','small'))
diagrams.sort(key=lambda item: item[0])
for idx,(filename,title,desc,template) in enumerate(diagrams,1):
    story.extend([NextPageTemplate(template),PageBreak()])
    story.append(p(f'UML {idx:02d}  {title}','h1'))
    story.append(p(desc))
    size=A3 if template=='drawingP' else landscape(A3)
    story.append(Spacer(1,10))
    story.append(VectorDiagram(ROOT/'docs/diagrams'/f'{filename}.svg',size[0]-110,size[1]-225))

section('08  Requirements traceability','traceability',template='body')
story.append(p('These are planned acceptance checks. They have not been executed against an application.'))
text=load('TRACEABILITY.md')
text=re.sub(r'Sources live in .*?\[UML.md\]\(UML.md\)\.', 'See the numbered models in Section 07.',text)
text=text.replace('## Confirmed needs mapped to the specification','## Confirmed product needs mapped to the specification')
text=text.replace('| User decision |','| Product decision |')
text=text.replace('README evidence limits','Executive brief and source limitations')
text=text.replace('SRS scope, FR-06, UC-02','SRS scope, FR-06, UC-02')
emit_markdown(text)

section('09  Review and document control','review')
emit_markdown('''
## Review sequence
1. Confirm the first-release scope and the child access/recovery model.
2. Agree learner-data privacy, reflection modes, and progress expectations across devices.
3. Approve supported content templates and assign editorial ownership.
4. Resolve launch-platform, connectivity, operating, and data-retention decisions.
5. Baseline the SRS, then update the use cases, UML, and acceptance mapping together.

## Change control
Keep requirement IDs stable. Record an explicit decision before promoting a proposal to the approved baseline. Revise related diagrams and acceptance checks when behavior changes. A routine content edit must not silently rewrite historical learner completion.

## Source material
- **Presentation 13.pptx:** supplied conceptual project presentation.
- **Expanded project notes:** supplied written material about the learning themes and journey.
- **Client revisions:** ages 10-14, complete Dhikr door, character creation, locked-door map, Arabic-first localization, and removal of the mother role. Written/voice reflection and child access/recovery remain open.
- **Product-planning decisions:** confirmed ages 10-14, child-only scope, first door, visual direction, framework, and admin content updates.

## Verification status
The source pack contains 30 active functional requirements plus 5 retired identifiers, 14 nonfunctional requirements, 15 business rules, ten active use cases and two retired identifiers, and ten UML diagrams. Requirement identifiers and traceability coverage were checked, and the diagrams were rendered from their editable sources. These documentation checks do not substitute for application, security, accessibility, content, or usability acceptance testing.

## Review record
Record agreed decisions and revisions here before establishing an approved baseline.

| Field | Review entry |
|---|---|
| Document version | 0.3 - client review draft |
| Review date | To be recorded |
| Reviewer / role | To be recorded |
| Decisions accepted | Reference C-, P-, OQ-, or requirement IDs |
| Changes requested | Reference requirement IDs and affected models |
| Baseline status | Not yet approved |
''')

while story and isinstance(story[-1], Spacer): story.pop()
doc.multiBuild(story)
reader=PdfReader(str(PDF))
manifest=[]
alltext='\n'.join(page.extract_text() or '' for page in reader.pages)
for i,page in enumerate(reader.pages,1):
    txt=page.extract_text() or ''
    manifest.append({'page':i,'width':float(page.mediabox.width),'height':float(page.mediabox.height),'chars':len(txt),'opening':txt[:140]})
missing=[f'{prefix}-{n:02}' for prefix,count in [('FR',35),('NFR',14),('BR',15),('UC',12)] for n in range(1,count+1) if f'{prefix}-{n:02}' not in alltext]
assert not missing, missing
assert 'C:/Users/' not in alltext and '.codex-inspect' not in alltext
(ROOT/'.codex-inspect/pdf-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pdf':str(PDF),'pages':len(reader.pages),'bytes':PDF.stat().st_size,'requirement_coverage':'PASS'},indent=2))
